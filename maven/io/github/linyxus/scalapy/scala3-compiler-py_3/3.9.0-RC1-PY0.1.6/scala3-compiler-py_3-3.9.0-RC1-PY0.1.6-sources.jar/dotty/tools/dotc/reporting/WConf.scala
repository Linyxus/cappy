package dotty.tools
package dotc
package reporting

import dotty.tools.dotc.core.Contexts.*
import dotty.tools.dotc.util.{NoSourcePosition, SourcePosition}
import dotty.tools.dotc.interfaces.SourceFile
import dotty.tools.dotc.reporting.MessageFilter.SourcePattern

import java.util.regex.PatternSyntaxException
import scala.PartialFunction.cond
import scala.annotation.internal.sharable
import scala.util.matching.Regex

enum MessageFilter:
  def matches(message: Diagnostic): Boolean =
    import Diagnostic.*
    this match
    case Any => true
    case Configuration => message.isInstanceOf[ConfigurationWarning]
    case Deprecated => message.isInstanceOf[DeprecationWarning]
    case Feature => message.isInstanceOf[FeatureWarning]
    case Unchecked => message.isInstanceOf[UncheckedWarning]
    case MessageID(errorId) => message.msg.errorId == errorId
    case MessagePattern(pattern) =>
      val noHighlight = message.msg.message.replaceAll("\\e\\[[\\d;]*[^\\d;]", "")
      pattern.findFirstIn(noHighlight).nonEmpty
    case SourcePattern(pattern) =>
      val source = message.position.orElse(NoSourcePosition).source()
      val path = source.jfile()
        .map(_.toPath.toAbsolutePath.toUri.normalize().getRawPath)
        .orElse(source.path())
      pattern.findFirstIn(path).nonEmpty
    case Origin(pattern) =>
      message match
      case message: OriginWarning if message.origin != OriginWarning.NoOrigin =>
        pattern.findFirstIn(message.origin).nonEmpty
      case _ => false
    case None => false

  case Any, Configuration, Deprecated, Feature, Unchecked, None
  case MessagePattern(pattern: Regex)
  case MessageID(errorId: ErrorMessageID)
  case SourcePattern(pattern: Regex)
  case Origin(pattern: Regex)

enum Action:
  case Error, Warning, Verbose, Info, Silent, Default

final case class WConf(confs: List[(List[MessageFilter], Action)]):
  def action(message: Diagnostic): Action =
    confs.collectFirst:
      case (filters, action) if filters.forall(_.matches(message)) => action
    .getOrElse(Action.Default)

object WConf:
  import Action.*
  import MessageFilter.*

  private type Conf = (List[MessageFilter], Action)

  def parseAction(s: String): Either[List[String], Action] = s match
    case "error"   | "e" => Right(Error)
    case "warning" | "w" => Right(Warning)
    case "verbose" | "v" => Right(Verbose)
    case "info"    | "i" => Right(Info)
    case "silent"  | "s" => Right(Silent)
    case _               => Left(List(s"unknown action: `$s`"))

  private def regex(s: String) =
    try Right(s.r)
    catch case e: PatternSyntaxException => Left(s"invalid pattern `$s`: ${e.getMessage}")

  @sharable val Splitter = raw"([^=]+)=(.+)".r
  @sharable val ErrorId = raw"E?(\d+)".r

  def parseFilters(s: String): Either[List[String], List[MessageFilter]] =
    // TODO: don't split on escaped \&
    val (parseErrors, filters) = s.split('&').toList.partitionMap(parseFilter)
    if parseErrors.nonEmpty then Left(parseErrors)
    else if filters.isEmpty then Left(List("no filters or no action defined"))
    else Right(filters)

  def parseFilter(s: String): Either[String, MessageFilter] = s match
    case "any" => Right(Any)
    case Splitter(filter, conf) =>
      assert(filter != null && conf != null, s"$Splitter should not match with missing groups")
      filter match
        case "msg" => regex(conf).map(MessagePattern.apply)
        case "id" => conf match
          case ErrorId(num) =>
            assert(num != null, s"$ErrorId should not match with missing groups")
            ErrorMessageID.fromErrorNumber(num.toInt) match
              case Some(errId) if errId.isActive => Right(MessageID(errId))
              case Some(errId) => Left(s"E${num} is marked as inactive.")
              case _ => Left(s"Unknown error message number: E${num}")
          case _ =>
            Left(s"invalid error message id: $conf")
        case "name" =>
          try Right(MessageID(ErrorMessageID.valueOf(conf + "ID")))
          catch case _: IllegalArgumentException => Left(s"unknown error message name: $conf")

        case "cat" => conf match
          case "configuration" => Right(Configuration)
          case "deprecation" => Right(Deprecated)
          case "feature"     => Right(Feature)
          case "unchecked"   => Right(Unchecked)
          case _             => Left(s"unknown category: $conf")

        case "src" => regex(conf).map(SourcePattern.apply)
        case "origin" => regex(conf).map(Origin.apply)

        case _ => Left(s"unknown filter: $filter")
    case _ => Left(s"unknown filter: $s")

  def parsed(using Context): WConf =
    val setting = ctx.settings.Wconf.value
    def cached = ctx.base.wConfCache
    if cached == null || cached._1 != setting then
      val conf = fromSettings(setting)
      ctx.base.wConfCache = (setting, conf.getOrElse(WConf(Nil)))
      conf.swap.foreach(msgs =>
        val multiHelp =
          if setting.sizeIs > 1 then
            """
              |Note: for multiple filters, use `-Wconf:filter1:action1,filter2:action2`
              |      or alternatively          `-Wconf:filter1:action1 -Wconf:filter2:action2`""".stripMargin
          else ""
        report.warning(s"Failed to parse `-Wconf` configuration: ${ctx.settings.Wconf.value.mkString(",")}\n${msgs.mkString("\n")}$multiHelp"))
    cached._2

  def fromSettings(settings: List[String]): Either[List[String], WConf] =
    if (settings.isEmpty) Right(WConf(Nil))
    else
      val parsedConfs: List[Either[List[String], (List[MessageFilter], Action)]] = settings.reverse.map(conf =>
        val filtersAndAction = conf.split(':')
        if filtersAndAction.length != 2 then Left(List("exactly one `:` expected (<filter>&...&<filter>:<action>)"))
        else
          parseFilters(filtersAndAction(0)).flatMap(filters =>
            parseAction(filtersAndAction(1)).map((filters, _))))
      val (parseErrorss, configs) = parsedConfs.partitionMap(identity)
      if (parseErrorss.nonEmpty) Left(parseErrorss.flatten)
      else Right(WConf(configs))

class Suppression(val annotPos: SourcePosition, val filters: List[MessageFilter], val start: Int, val end: Int, val verbose: Boolean):
  inline def unusedState = 0
  inline def usedState = 1
  inline def supersededState = 2
  private var _used = unusedState
  def used: Boolean = _used == usedState
  def superseded: Boolean = _used == supersededState
  def markUsed(): Unit =
    _used = usedState
  def markSuperseded(): Unit =
    _used = supersededState
  def matches(dia: Diagnostic): Boolean =
    val pos = dia.pos
    def posMatches =
         start <= pos.start && pos.end <= end
      || pos.inlinePosStack.exists(p => start <= p.start && p.end <= end)
    pos.exists && posMatches && filters.forall(_.matches(dia))

  override def toString = s"Suppress in ${annotPos.source} $start..$end [${filters.mkString(", ")}]"
end Suppression
