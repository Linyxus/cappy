/*
 * Scala (https://www.scala-lang.org)
 *
 * Copyright EPFL and Lightbend, Inc. dba Akka
 *
 * Licensed under Apache License 2.0
 * (http://www.apache.org/licenses/LICENSE-2.0).
 *
 * See the NOTICE file distributed with this work for
 * additional information regarding copyright ownership.
 */

package scala

import scala.language.`2.13`

/** `Long`, a 64-bit signed integer (equivalent to Java's `long` primitive type) is a
 *  subtype of [[scala.AnyVal]]. Instances of `Long` are not
 *  represented by an object in the underlying runtime system.
 *
 *  There is an implicit conversion from [[scala.Long]] => [[scala.runtime.RichLong]]
 *  which provides useful non-primitive operations.
 */
final abstract class Long private extends AnyVal {
  def toByte: Byte
  def toShort: Short
  def toChar: Char
  def toInt: Int
  def toLong: Long
  def toFloat: Float
  def toDouble: Double

  /** Returns the bitwise negation of this value.
   *  @example ```
   *  ~5 == -6
   *  // in binary: ~00000101 ==
   *  //             11111010
   *  ```
   */
  def unary_~ : Long
  /** Returns this value, unmodified. */
  def unary_+ : Long
  /** Returns the negation of this value. */
  def unary_- : Long

  @deprecated("Adding a number and a String is deprecated. Use the string interpolation `s\"$num$str\"`", "2.13.0")
  def +(x: String): String

  /** Returns this value bit-shifted left by the specified number of bits,
   *         filling in the new right bits with zeroes.
   *  @example
   *  ```
   *  6 << 3 == 48 // in binary: 0110 << 3 == 0110000
   *  ```
   *
   *  @param x the number of bits to shift left
   */
  def <<(x: Int): Long
  /** Returns this value bit-shifted left by the specified number of bits,
   *         filling in the new right bits with zeroes.
   *  @example
   *  ```
   *  6 << 3 == 48 // in binary: 0110 << 3 == 0110000
   *  ```
   *
   *  @param x the number of bits to shift left
   */
  def <<(x: Long): Long
  /** Returns this value bit-shifted right by the specified number of bits,
   *         filling the new left bits with zeroes.
   *  @example ``` 21 >>> 3 == 2 // in binary: 010101 >>> 3 == 010 ```
   *  @example ```
   *  -21 >>> 3 == 536870909
   *  // in binary: 11111111 11111111 11111111 11101011 >>> 3 ==
   *  //            00011111 11111111 11111111 11111101
   *  ```
   *
   *  @param x the number of bits to shift right
   */
  def >>>(x: Int): Long
  /** Returns this value bit-shifted right by the specified number of bits,
   *         filling the new left bits with zeroes.
   *  @example ``` 21 >>> 3 == 2 // in binary: 010101 >>> 3 == 010 ```
   *  @example ```
   *  -21 >>> 3 == 536870909
   *  // in binary: 11111111 11111111 11111111 11101011 >>> 3 ==
   *  //            00011111 11111111 11111111 11111101
   *  ```
   *
   *  @param x the number of bits to shift right
   */
  def >>>(x: Long): Long
  /** Returns this value bit-shifted right by the specified number of bits,
   *         filling in the left bits with the same value as the left-most bit of this.
   *         The effect of this is to retain the sign of the value.
   *  @example ```
   *  -21 >> 3 == -3
   *  // in binary: 11111111 11111111 11111111 11101011 >> 3 ==
   *  //            11111111 11111111 11111111 11111101
   *  ```
   *
   *  @param x the number of bits to shift right
   */
  def >>(x: Int): Long
  /** Returns this value bit-shifted right by the specified number of bits,
   *         filling in the left bits with the same value as the left-most bit of this.
   *         The effect of this is to retain the sign of the value.
   *  @example ```
   *  -21 >> 3 == -3
   *  // in binary: 11111111 11111111 11111111 11101011 >> 3 ==
   *  //            11111111 11111111 11111111 11111101
   *  ```
   *
   *  @param x the number of bits to shift right
   */
  def >>(x: Long): Long

  /** Returns `true` if this value is equal to x, `false` otherwise. */
  def ==(x: Byte): Boolean
  /** Returns `true` if this value is equal to x, `false` otherwise. */
  def ==(x: Short): Boolean
  /** Returns `true` if this value is equal to x, `false` otherwise. */
  def ==(x: Char): Boolean
  /** Returns `true` if this value is equal to x, `false` otherwise. */
  def ==(x: Int): Boolean
  /** Returns `true` if this value is equal to x, `false` otherwise. */
  def ==(x: Long): Boolean
  /** Returns `true` if this value is equal to x, `false` otherwise. */
  def ==(x: Float): Boolean
  /** Returns `true` if this value is equal to x, `false` otherwise. */
  def ==(x: Double): Boolean

  /** Returns `true` if this value is not equal to x, `false` otherwise. */
  def !=(x: Byte): Boolean
  /** Returns `true` if this value is not equal to x, `false` otherwise. */
  def !=(x: Short): Boolean
  /** Returns `true` if this value is not equal to x, `false` otherwise. */
  def !=(x: Char): Boolean
  /** Returns `true` if this value is not equal to x, `false` otherwise. */
  def !=(x: Int): Boolean
  /** Returns `true` if this value is not equal to x, `false` otherwise. */
  def !=(x: Long): Boolean
  /** Returns `true` if this value is not equal to x, `false` otherwise. */
  def !=(x: Float): Boolean
  /** Returns `true` if this value is not equal to x, `false` otherwise. */
  def !=(x: Double): Boolean

  /** Returns `true` if this value is less than x, `false` otherwise.
   *
   *  @param x the value to compare against
   */
  def <(x: Byte): Boolean
  /** Returns `true` if this value is less than x, `false` otherwise.
   *
   *  @param x the value to compare against
   */
  def <(x: Short): Boolean
  /** Returns `true` if this value is less than x, `false` otherwise.
   *
   *  @param x the value to compare against
   */
  def <(x: Char): Boolean
  /** Returns `true` if this value is less than x, `false` otherwise.
   *
   *  @param x the value to compare against
   */
  def <(x: Int): Boolean
  /** Returns `true` if this value is less than x, `false` otherwise.
   *
   *  @param x the value to compare against
   */
  def <(x: Long): Boolean
  /** Returns `true` if this value is less than x, `false` otherwise.
   *
   *  @param x the value to compare against
   */
  def <(x: Float): Boolean
  /** Returns `true` if this value is less than x, `false` otherwise.
   *
   *  @param x the value to compare against
   */
  def <(x: Double): Boolean

  /** Returns `true` if this value is less than or equal to x, `false` otherwise. */
  def <=(x: Byte): Boolean
  /** Returns `true` if this value is less than or equal to x, `false` otherwise. */
  def <=(x: Short): Boolean
  /** Returns `true` if this value is less than or equal to x, `false` otherwise. */
  def <=(x: Char): Boolean
  /** Returns `true` if this value is less than or equal to x, `false` otherwise. */
  def <=(x: Int): Boolean
  /** Returns `true` if this value is less than or equal to x, `false` otherwise. */
  def <=(x: Long): Boolean
  /** Returns `true` if this value is less than or equal to x, `false` otherwise. */
  def <=(x: Float): Boolean
  /** Returns `true` if this value is less than or equal to x, `false` otherwise. */
  def <=(x: Double): Boolean

  /** Returns `true` if this value is greater than x, `false` otherwise.
   *
   *  @param x the value to compare against
   */
  def >(x: Byte): Boolean
  /** Returns `true` if this value is greater than x, `false` otherwise.
   *
   *  @param x the value to compare against
   */
  def >(x: Short): Boolean
  /** Returns `true` if this value is greater than x, `false` otherwise.
   *
   *  @param x the value to compare against
   */
  def >(x: Char): Boolean
  /** Returns `true` if this value is greater than x, `false` otherwise.
   *
   *  @param x the value to compare against
   */
  def >(x: Int): Boolean
  /** Returns `true` if this value is greater than x, `false` otherwise.
   *
   *  @param x the value to compare against
   */
  def >(x: Long): Boolean
  /** Returns `true` if this value is greater than x, `false` otherwise.
   *
   *  @param x the value to compare against
   */
  def >(x: Float): Boolean
  /** Returns `true` if this value is greater than x, `false` otherwise.
   *
   *  @param x the value to compare against
   */
  def >(x: Double): Boolean

  /** Returns `true` if this value is greater than or equal to x, `false` otherwise. */
  def >=(x: Byte): Boolean
  /** Returns `true` if this value is greater than or equal to x, `false` otherwise. */
  def >=(x: Short): Boolean
  /** Returns `true` if this value is greater than or equal to x, `false` otherwise. */
  def >=(x: Char): Boolean
  /** Returns `true` if this value is greater than or equal to x, `false` otherwise. */
  def >=(x: Int): Boolean
  /** Returns `true` if this value is greater than or equal to x, `false` otherwise. */
  def >=(x: Long): Boolean
  /** Returns `true` if this value is greater than or equal to x, `false` otherwise. */
  def >=(x: Float): Boolean
  /** Returns `true` if this value is greater than or equal to x, `false` otherwise. */
  def >=(x: Double): Boolean

  /** Returns the bitwise OR of this value and `x`.
   *  @example ```
   *  (0xf0 | 0xaa) == 0xfa
   *  // in binary:   11110000
   *  //            | 10101010
   *  //              --------
   *  //              11111010
   *  ```
   *
   *  @param x the value to OR with this value
   */
  def |(x: Byte): Long
  /** Returns the bitwise OR of this value and `x`.
   *  @example ```
   *  (0xf0 | 0xaa) == 0xfa
   *  // in binary:   11110000
   *  //            | 10101010
   *  //              --------
   *  //              11111010
   *  ```
   *
   *  @param x the value to OR with this value
   */
  def |(x: Short): Long
  /** Returns the bitwise OR of this value and `x`.
   *  @example ```
   *  (0xf0 | 0xaa) == 0xfa
   *  // in binary:   11110000
   *  //            | 10101010
   *  //              --------
   *  //              11111010
   *  ```
   *
   *  @param x the value to OR with this value
   */
  def |(x: Char): Long
  /** Returns the bitwise OR of this value and `x`.
   *  @example ```
   *  (0xf0 | 0xaa) == 0xfa
   *  // in binary:   11110000
   *  //            | 10101010
   *  //              --------
   *  //              11111010
   *  ```
   *
   *  @param x the value to OR with this value
   */
  def |(x: Int): Long
  /** Returns the bitwise OR of this value and `x`.
   *  @example ```
   *  (0xf0 | 0xaa) == 0xfa
   *  // in binary:   11110000
   *  //            | 10101010
   *  //              --------
   *  //              11111010
   *  ```
   *
   *  @param x the value to OR with this value
   */
  def |(x: Long): Long

  /** Returns the bitwise AND of this value and `x`.
   *  @example ```
   *  (0xf0 & 0xaa) == 0xa0
   *  // in binary:   11110000
   *  //            & 10101010
   *  //              --------
   *  //              10100000
   *  ```
   *
   *  @param x the value to AND with this value
   */
  def &(x: Byte): Long
  /** Returns the bitwise AND of this value and `x`.
   *  @example ```
   *  (0xf0 & 0xaa) == 0xa0
   *  // in binary:   11110000
   *  //            & 10101010
   *  //              --------
   *  //              10100000
   *  ```
   *
   *  @param x the value to AND with this value
   */
  def &(x: Short): Long
  /** Returns the bitwise AND of this value and `x`.
   *  @example ```
   *  (0xf0 & 0xaa) == 0xa0
   *  // in binary:   11110000
   *  //            & 10101010
   *  //              --------
   *  //              10100000
   *  ```
   *
   *  @param x the value to AND with this value
   */
  def &(x: Char): Long
  /** Returns the bitwise AND of this value and `x`.
   *  @example ```
   *  (0xf0 & 0xaa) == 0xa0
   *  // in binary:   11110000
   *  //            & 10101010
   *  //              --------
   *  //              10100000
   *  ```
   *
   *  @param x the value to AND with this value
   */
  def &(x: Int): Long
  /** Returns the bitwise AND of this value and `x`.
   *  @example ```
   *  (0xf0 & 0xaa) == 0xa0
   *  // in binary:   11110000
   *  //            & 10101010
   *  //              --------
   *  //              10100000
   *  ```
   *
   *  @param x the value to AND with this value
   */
  def &(x: Long): Long

  /** Returns the bitwise XOR of this value and `x`.
   *  @example ```
   *  (0xf0 ^ 0xaa) == 0x5a
   *  // in binary:   11110000
   *  //            ^ 10101010
   *  //              --------
   *  //              01011010
   *  ```
   *
   *  @param x the value to XOR with this value
   */
  def ^(x: Byte): Long
  /** Returns the bitwise XOR of this value and `x`.
   *  @example ```
   *  (0xf0 ^ 0xaa) == 0x5a
   *  // in binary:   11110000
   *  //            ^ 10101010
   *  //              --------
   *  //              01011010
   *  ```
   *
   *  @param x the value to XOR with this value
   */
  def ^(x: Short): Long
  /** Returns the bitwise XOR of this value and `x`.
   *  @example ```
   *  (0xf0 ^ 0xaa) == 0x5a
   *  // in binary:   11110000
   *  //            ^ 10101010
   *  //              --------
   *  //              01011010
   *  ```
   *
   *  @param x the value to XOR with this value
   */
  def ^(x: Char): Long
  /** Returns the bitwise XOR of this value and `x`.
   *  @example ```
   *  (0xf0 ^ 0xaa) == 0x5a
   *  // in binary:   11110000
   *  //            ^ 10101010
   *  //              --------
   *  //              01011010
   *  ```
   *
   *  @param x the value to XOR with this value
   */
  def ^(x: Int): Long
  /** Returns the bitwise XOR of this value and `x`.
   *  @example ```
   *  (0xf0 ^ 0xaa) == 0x5a
   *  // in binary:   11110000
   *  //            ^ 10101010
   *  //              --------
   *  //              01011010
   *  ```
   *
   *  @param x the value to XOR with this value
   */
  def ^(x: Long): Long

  /** Returns the sum of this value and `x`.
   *
   *  @param x the value to add to this value
   */
  def +(x: Byte): Long
  /** Returns the sum of this value and `x`.
   *
   *  @param x the value to add to this value
   */
  def +(x: Short): Long
  /** Returns the sum of this value and `x`.
   *
   *  @param x the value to add to this value
   */
  def +(x: Char): Long
  /** Returns the sum of this value and `x`.
   *
   *  @param x the value to add to this value
   */
  def +(x: Int): Long
  /** Returns the sum of this value and `x`.
   *
   *  @param x the value to add to this value
   */
  def +(x: Long): Long
  /** Returns the sum of this value and `x`.
   *
   *  @param x the value to add to this value
   */
  def +(x: Float): Float
  /** Returns the sum of this value and `x`.
   *
   *  @param x the value to add to this value
   */
  def +(x: Double): Double

  /** Returns the difference of this value and `x`.
   *
   *  @param x the value to subtract from this value
   */
  def -(x: Byte): Long
  /** Returns the difference of this value and `x`.
   *
   *  @param x the value to subtract from this value
   */
  def -(x: Short): Long
  /** Returns the difference of this value and `x`.
   *
   *  @param x the value to subtract from this value
   */
  def -(x: Char): Long
  /** Returns the difference of this value and `x`.
   *
   *  @param x the value to subtract from this value
   */
  def -(x: Int): Long
  /** Returns the difference of this value and `x`.
   *
   *  @param x the value to subtract from this value
   */
  def -(x: Long): Long
  /** Returns the difference of this value and `x`.
   *
   *  @param x the value to subtract from this value
   */
  def -(x: Float): Float
  /** Returns the difference of this value and `x`.
   *
   *  @param x the value to subtract from this value
   */
  def -(x: Double): Double

  /** Returns the product of this value and `x`.
   *
   *  @param x the value to multiply this value by
   */
  def *(x: Byte): Long
  /** Returns the product of this value and `x`.
   *
   *  @param x the value to multiply this value by
   */
  def *(x: Short): Long
  /** Returns the product of this value and `x`.
   *
   *  @param x the value to multiply this value by
   */
  def *(x: Char): Long
  /** Returns the product of this value and `x`.
   *
   *  @param x the value to multiply this value by
   */
  def *(x: Int): Long
  /** Returns the product of this value and `x`.
   *
   *  @param x the value to multiply this value by
   */
  def *(x: Long): Long
  /** Returns the product of this value and `x`.
   *
   *  @param x the value to multiply this value by
   */
  def *(x: Float): Float
  /** Returns the product of this value and `x`.
   *
   *  @param x the value to multiply this value by
   */
  def *(x: Double): Double

  /** Returns the quotient of this value and `x`.
   *
   *  @param x the value to divide this value by
   */
  def /(x: Byte): Long
  /** Returns the quotient of this value and `x`.
   *
   *  @param x the value to divide this value by
   */
  def /(x: Short): Long
  /** Returns the quotient of this value and `x`.
   *
   *  @param x the value to divide this value by
   */
  def /(x: Char): Long
  /** Returns the quotient of this value and `x`.
   *
   *  @param x the value to divide this value by
   */
  def /(x: Int): Long
  /** Returns the quotient of this value and `x`.
   *
   *  @param x the value to divide this value by
   */
  def /(x: Long): Long
  /** Returns the quotient of this value and `x`.
   *
   *  @param x the value to divide this value by
   */
  def /(x: Float): Float
  /** Returns the quotient of this value and `x`.
   *
   *  @param x the value to divide this value by
   */
  def /(x: Double): Double

  /** Returns the remainder of the division of this value by `x`.
   *
   *  @param x the divisor
   */
  def %(x: Byte): Long
  /** Returns the remainder of the division of this value by `x`.
   *
   *  @param x the divisor
   */
  def %(x: Short): Long
  /** Returns the remainder of the division of this value by `x`.
   *
   *  @param x the divisor
   */
  def %(x: Char): Long
  /** Returns the remainder of the division of this value by `x`.
   *
   *  @param x the divisor
   */
  def %(x: Int): Long
  /** Returns the remainder of the division of this value by `x`.
   *
   *  @param x the divisor
   */
  def %(x: Long): Long
  /** Returns the remainder of the division of this value by `x`.
   *
   *  @param x the divisor
   */
  def %(x: Float): Float
  /** Returns the remainder of the division of this value by `x`.
   *
   *  @param x the divisor
   */
  def %(x: Double): Double

  // Provide a more specific return type for Scaladoc
  override def getClass(): Class[Long] = ???
}

object Long extends AnyValCompanion {
  /** The smallest value representable as a `Long`. */
  final val MinValue = java.lang.Long.MIN_VALUE

  /** The largest value representable as a `Long`. */
  final val MaxValue = java.lang.Long.MAX_VALUE

  /** Transforms a value type into a boxed reference type.
   *
   *  Runtime implementation determined by `scala.runtime.BoxesRunTime.boxToLong`. See [src/library/scala/runtime/BoxesRunTime.java](https://github.com/scala/scala).
   *
   *  @param  x   the Long to be boxed
   *  @return     a java.lang.Long offering `x` as its underlying value.
   */
  def box(x: Long): java.lang.Long = ???

  /** Transforms a boxed type into a value type.  Note that this
   *  method is not typesafe: it accepts any Object, but will throw
   *  an exception if the argument is not a java.lang.Long.
   *
   *  Runtime implementation determined by `scala.runtime.BoxesRunTime.unboxToLong`. See [src/library/scala/runtime/BoxesRunTime.java](https://github.com/scala/scala).
   *
   *  @param  x   the java.lang.Long to be unboxed.
   *  @return     the Long resulting from calling longValue() on `x`
   *  @throws     ClassCastException  if the argument is not a java.lang.Long
   */
  def unbox(x: java.lang.Object): Long = ???

  /** The `String` representation of the `scala.Long` companion object. */
  override def toString() = "object scala.Long"
  /** Language mandated coercions from `Long` to "wider" types. */
  import scala.language.implicitConversions
  @deprecated("Implicit conversion from Long to Float is dangerous because it loses precision. Write `.toFloat` instead.", "2.13.1")
  implicit def long2float(x: Long): Float = x.toFloat
  @deprecated("Implicit conversion from Long to Double is dangerous because it loses precision. Write `.toDouble` instead.", "2.13.1")
  implicit def long2double(x: Long): Double = x.toDouble
}

